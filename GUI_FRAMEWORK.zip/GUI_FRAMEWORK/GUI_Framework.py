import openai
import customtkinter as ctk

class UIWindow(ctk.CTk):
    def __init__(self, master=None):
        super().__init__(master)

        self.main_header_lbl = ctk.CTkLabel(self, text="Welcome to a revolutionary new learning experience powered by Open AI")

        # Create dropdowns for subjects and levels
        subjects = ["Math", "History", "Geography", "Health", "Science"]
        levels = ["Elementary", "Middle", "High", "College"]
        self.subject_dropdown = ctk.CTkOptionMenu(self, values=subjects)
        self.level_dropdown = ctk.CTkOptionMenu(self, values=levels)

        #------------------ Create question input field -------------------
        # Create CTkLabel for AI question input
        self.question_label = ctk.CTkLabel(self, text="Welcome to a revolutionary new learning \n experience powered by Open AI")
        # Create CTkEntry for AI question input
        self.question_entry = ctk.CTkEntry(self)
        # Create CTkButton to submit user ai question
        self.submit_button = ctk.CTkButton(self, text="Submit", command=self.submit_question)

        # Create CTkButton for speech recognition
        self.speak_button = ctk.CTkButton(self, text="Speak", command=self.start_speech_recognition)

        # Create CTkText for AI response
        self.question_response = ctk.CTkTextbox(self)

        # Pack all widgets into main window
        self.subject_dropdown.grid(row=7, column=2, padx=20, pady=20)
        self.level_dropdown.grid(row=7, column=4, padx=20, pady=20)

        self.question_label.grid(row=7, column=4, columnspan=4, padx=20, pady=20)
        self.question_entry.grid(row=13, column=0, columnspan=2)

        self.submit_button.grid(row=8, column=4)

        self.question_label.grid(row=2, column=0, sticky="W")
        self.question_entry.grid(row=8, column=1, columnspan=2)

        self.speak_button.grid(row=10, column=2, columnspan=4, )

        self.question_response.grid(row=4, column=2, columnspan=4, padx=20, pady=20)

    def submit_question(self):

        # Set up the OpenAI API client
        openai.api_key = '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'
        
        subject = self.subject_dropdown.get()
        level = self.level_dropdown.get()
        question = self.question_entry.get()
        prompt = f"I need help with {subject} at the {level} level. My question is: {question}"
        try:
            response = openai.Completion.create(
                engine="davinci",
                prompt=prompt,
                max_tokens=60,
                n=1,
                stop=None,
                temperature=0.7,)
            answer = response.choices[0].text
            # display the answer in a label or messagebox
        except openai.Error as e:
            # display an error message to the user
            pass

    def ask_openai(self):
        # Get the question from the AI question input
        question = self.question_entry.get()

        # Set up the OpenAI API client
        openai.api_key = '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'

        # Set up the parameters for the OpenAI API request
        model_engine = "davinci"  # The name of the OpenAI model to use
        prompt = f"Q: {question}\nA:"  # The prompt to send to the OpenAI API
        max_tokens = 1024  # The maximum number of tokens (words) in the response
        temperature = 0.7  # Controls the "creativity" of the response
        stop = "\n"  # The character that tells the OpenAI API to stop generating text

        # Send the request to the OpenAI API
        response = openai.Completion.create(
            engine=model_engine,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            stop=stop)
        
    def start_speech_recognition(self):
        # use OpenAI's Whisper API for speech recognition
        pass
        
# Create and start the UIWindow
if __name__ == "__main__":
    window = UIWindow()
    window.mainloop()

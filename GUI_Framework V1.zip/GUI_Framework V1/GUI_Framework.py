import openai
import customtkinter as ctk

class UIWindow(ctk.CTk):
    def __init__(self, master=None):
        super().__init__(master)

        # Create App header
        self.app_header_lbl = ctk.CTkLabel(self, text="AI Tutor")
        
        # Create headings for UI elements
        self.main_heading_lbl = ctk.CTkLabel(self, text="Welcome to a revolutionary new learning \n experience powered by Open AI")
        self.ai_response_heading_lbl = ctk.CTkLabel(self, text="AI Response:")
        self.dropdown_heading_lbl = ctk.CTkLabel(self, text="Choose your desired subject \n and study level below:")
        
        # Create dropdowns for subjects and levels
        subjects = ["Math", "History", "Geography", "Health", "Science"]
        levels = ["Elementary", "Middle", "High", "College"]
        self.subject_dropdown = ctk.CTkOptionMenu(self, values=subjects)
        self.level_dropdown = ctk.CTkOptionMenu(self, values=levels)

        # Create CTkText for AI response
        self.ai_response_field = ctk.CTkTextbox(self)

        #------------------ Create question input field -------------------
        # Create CTkEntry for AI question input
        self.question_entry_lbl = ctk.CTkLabel(self, text="What can I help you with?")
        self.question_entry = ctk.CTkEntry(self)
        # Create CTkButton to submit user question for processing by the AI
        self.submit_button = ctk.CTkButton(self, text="Submit", command=self.submit_question)

        # Create CTkButton to start speech recognition with Open AI Whisper
        self.speak_button = ctk.CTkButton(self, text="Speak", command=self.start_speech_recognition)

        # Pack all widgets into main window
        self.main_heading_lbl.grid(row=0, column=2, columnspan=4, padx=20, pady=10)
        self.ai_response_heading_lbl.grid(row=1, column=2, columnspan=4, padx=20, pady=10)
        self.ai_response_field.grid(row=2, column=2, columnspan=4, padx=20, pady=10)
        self.question_entry_lbl.grid(row=6, column=2, columnspan=4, padx=20, pady=10)
        self.question_entry.grid(row=7, column=2, columnspan=4, padx=20, pady=10)

        self.dropdown_heading_lbl.grid(row=3, column=2, columnspan=4, padx=5, pady=10)
        self.subject_dropdown.grid(row=4, column=2, padx=20, pady=10)
        self.level_dropdown.grid(row=4, column=4, padx=20, pady=10)


        self.submit_button.grid(row=8, column=2, columnspan=4, padx=10, pady=10)

        self.speak_button.grid(row=9, column=2, columnspan=4, padx=20, pady=20)

    def submit_question(self):

        # Set up the OpenAI API client
        openai.api_key = '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'
        
        subject = self.subject_dropdown.get()
        level = self.level_dropdown.get()
        question = self.question_entry.get()
        prompt = f"I need help with {subject} at the {level} level. My question is: {question}"
        try:
            response = openai.Completion.create(
                engine="davinci",
                prompt=prompt,
                max_tokens=60,
                n=1,
                stop=None,
                temperature=0.7,)
            answer = response.choices[0].text
            # display the answer in a label or messagebox
        except openai.Error as e:
            # display an error message to the user
            pass

    def ask_openai(self):
        # Get the question from the AI question input
        question = self.question_entry.get()

        # Set up the OpenAI API client
        openai.api_key = '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'

        # Set up the parameters for the OpenAI API request
        model_engine = "davinci"  # The name of the OpenAI model to use
        prompt = f"Q: {question}\nA:"  # The prompt to send to the OpenAI API
        max_tokens = 1024  # The maximum number of tokens (words) in the response
        temperature = 0.7  # Controls the "creativity" of the response
        stop = "\n"  # The character that tells the OpenAI API to stop generating text

        # Send the request to the OpenAI API
        response = openai.Completion.create(
            engine=model_engine,
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            stop=stop)
        
    def start_speech_recognition(self):
        # use OpenAI's Whisper API for speech recognition
        pass
        
# Create and start the UIWindow
if __name__ == "__main__":
    window = UIWindow()
    window.mainloop()
